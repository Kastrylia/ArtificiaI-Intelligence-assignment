Input:512x512 png image.File name should be 'input.png'
Output:512x512 png image. File name is 'output.png'

Every 10000 iterations program save current state as image named 'semiresult.png'

Every itreration program prints number of iteration and fit value in console.

IMPORTANT!Code has written on python 3.8 using PIL and numpy libraries.You should install it before running the code
https://numpy.org/
https://pillow.readthedocs.io/en/stable/index.html